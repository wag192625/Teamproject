package com.example.project.Controller.board;

import com.example.project.Entity.Member.Member;
import com.example.project.Entity.board.Board;
import com.example.project.Service.Member.MemberService;
import com.example.project.Service.board.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping(path="/otherpage/customerService")
public class BoardContoller {
//    private final MemberService memberService;
    private final BoardService boardService;

    @Autowired
    protected BoardContoller(BoardService boardService) {
        this.boardService = boardService;
    }

//    @GetMapping("/customerService")
//    public String customerService(Member member, Model model){
//        System.out.println("-------GetMapping고객센터--------");
//        model.addAttribute("memberId",member);
//
//
//        return "otherpage/customerService";
//    }
    @GetMapping("/inquiryBoardList")
    public String inquiryBoardList(Model model, Board board) {
        System.out.println("-------------------");
        List<Board> boardList = boardService.getBoardList(board);
        model.addAttribute("boardList", boardList);
        return "/otherpage/customerService/inquiryBoardList";
    }

    //겟보드
    @GetMapping("/inquiryBoard")
    public String getBoard(Board board, Model model) {
//        model.addAttribute("board", boardService.getBoard(board));
        return "otherpage/customerService/inquiryBoard";
    }


    //인서트
    @GetMapping("/inquiryInsertBoard")
    public String inquiryInsertBoard() {
        System.out.println("---------insertGetMapping---------");
        return "/otherpage/customerService/inquiryInsertBoard";
    }

    @PostMapping("/inquiryInsertBoard")
    public String inquiryInsertBoards(Board board) {
        System.out.println("-------insertPostMapping--------");
//        Long board_seq = boardService.insertBoard(board);
        boardService.insertBoard(board);
        return "redirect:/otherpage/customerService/inquiryBoardList";
    }


    //업데이트
    @GetMapping("updateBoard")
    public String updateBoard(Board board, Model model) {
        model.addAttribute("board", boardService.getBoard(board));
        return "/otherpage/customerService/inquiryBoard";
    }
    @PostMapping("/updateBoard")
    public String updateBoard(Board board) {
        boardService.updateBoard(board);
        return "redirect:/customerService/inquiryBoard?seq"+board.getBoardSeq();
    }


    //딜리트
    @GetMapping("/deleteBoard")
    public String deleteBoard(Board board) {
        boardService.deleteBoard(board);
        return "redirect:/otherpage/customerService/inquiryBoardList";
    }



//
//    @GetMapping("otherpage/customerService")
//    public String customerService(Member member,Model model) {
//
//        System.out.println("----GetMapping 고객센터-----");
//        Member findMember = memberService.getMember(member);
//        System.out.println(findMember.getMemberId());
//        //회원 로그인을 할 경우 아이디와 비밀번호가 일치하지 않으면 로그인 페이지로 되돌아 온다.
////        ***** 로그인 하지 않을시, 고객센터 이용 불가능 ****
//        if (member.getMemberId().equals(null)&&member.getMemberId().equals("")) {
//            model.addAttribute("memberId", findMember);
//            System.out.println("고객센터는 로그인시 이용 가능합니다!");
//            return "/contents/member/login";}
//
////        else if(findMember.getMemberId().equals("any2730")){
////            model.addAttribute("memberId", findMember);
////
////            System.out.println("로그인 성공!!!고객센터 진입");
////            return "/otherpage/customerService";
////        }
//        else {
//            System.out.println("로그인 성공!!!고객센터 진입");
//            return "/otherpage/customerService";
//        }
//    }



//    @PostMapping("/otherpage/customerService")
//    public String customerServices(Member member, Model model) {
//        System.out.println("---------고객센터---------");
//        Member findMember = memberService.getMember(member);
//        //아이디, 비번 일치해야지 로그인 가능
//        //회원 로그인을 할 경우 아이디와 비밀번호가 일치하지 않으면 로그인 페이지로 되돌아 온다.
//        if (findMember != null
//                && findMember.getMemberId().equals(member.getMemberId())
//                && findMember.getMemberPassword().equals(member.getMemberPassword())) {
//            model.addAttribute("member", findMember);
//            System.out.println("로그인 성공!!!");
//            return "/otherpage/customerService";
//        } else {
//            System.out.println("아이디, 비밀번호를 다시 입력해주세요!");
//            return "contents/member/login";
//        }
//
//    }

}
