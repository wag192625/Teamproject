package com.example.project.Entity.board;

import com.example.project.Entity.base.BaseTimeEntity;
import lombok.*;
import org.hibernate.annotations.ColumnDefault;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Board extends BaseTimeEntity {

    @Id
    @GeneratedValue
    private Long boardSeq;

    @Column
    private String title;

//    @Column
//    private String member;
    //조인은 나중에

    @Column
    private String writer;

    @Column
    private String category;

    @Setter
    @Column(nullable = false)
    @ColumnDefault("'no content'")
    private String content;
}